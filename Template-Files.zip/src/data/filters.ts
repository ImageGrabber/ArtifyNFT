export const filterOptions = {
    status: ["Buy Now", "On Auction", "New"],
    price: ["< 1 ETH", "1 - 5 ETH", "5 - 10 ETH", "> 10 ETH"],
    collections: ["Abstract Dreams", "Cyber Punks", "Pixel World", "Nature's Soul"],
    chains: ["Ethereum", "Polygon", "Solana", "Tezos"]
};
